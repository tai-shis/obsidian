Missing a few "not-so-difficult" concepts, refer to slides for information regarding those
[[Introduction]]
[[Conversions Between Bases]]
[[Data Representation]]
[[Intro to Computer Architecture]]
[[Assembly Basics]]
[[Subroutines]]

[[Array Indexing]]
[[Instruction Translation]]
[[Floating Point Numbers]]
[[Dynamic Memory Access]]
[[Assembling, Linker, and Loader]]